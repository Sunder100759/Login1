package com.example.login;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener {


    Button Login;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Login = (Button) findViewById(R.id.button_login);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent instant = new Intent(MainActivity.this, Login.class);
                startActivity(instant);


            }
        });

        //Open Registration Activity
        Button buttonRegistration = findViewById(R.id.button_Registration);
        buttonRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Registration.class);
                startActivity(intent);
            }
        });


        Button Login_id = findViewById(R.id.button_login);
        Button Registration = findViewById(R.id.button_Registration);


        Login_id.setOnClickListener(this);
        Registration.setOnClickListener(this);

    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button_login:
                Toast.makeText(this, "Acticity Login_id", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(MainActivity.this,Login.class);
                startActivity(i);
                break;
            case R.id.button_Registration:
                Toast.makeText(this, "Activity login", Toast.LENGTH_SHORT).show();
                Intent o = new Intent(MainActivity.this,Registration.class);
                startActivity(o);
                break;
        }

    }
}
