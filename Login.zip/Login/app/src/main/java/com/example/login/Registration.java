package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Registration extends AppCompatActivity {


    public static final String TAG = "TAG";
    EditText mFullName,mSid,mEmail,mPassword,mPhone,mDob;
    Button mRegistration;
    TextView mLoginBtn;
    ProgressBar progressBar;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        mFullName = findViewById(R.id.fullname);
        mSid = findViewById(R.id.Sid);
        mEmail = findViewById(R.id.Email);
        mPassword = findViewById(R.id.Password);
        mPhone = findViewById(R.id.Phone);
        mDob= findViewById(R.id.DOB);
        mRegistration = findViewById(R.id.RegistrationBtn);
        mLoginBtn = findViewById(R.id.RegistrationBtn);
        progressBar = findViewById(R.id.ProgressBar);


        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Login.class));
            }
        });


        mRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String Email = mEmail.getText().toString().trim();
                String password = mPassword.getText().toString().trim();
                final  String fullName = mFullName.getText().toString();
                final String Sid = mSid.getText().toString();
                final String phone = mPhone.getText().toString();
                final String dob = mDob.getText().toString();

                if(TextUtils.isEmpty(Email)){
                    mEmail.setError("Email is Required");
                    return;

                }


                if (TextUtils.isEmpty(password)){
                    mPassword.setError("Password is Required");
                    return;
                }

                if (password.length() < 6){
                    mPassword.setError("Password Must Be >= 6 character");
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);
            }
        });



    }
}